﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using notes.Data;
using notes.Models;

namespace notes.Controllers
{
    public class NotesController : Controller
    {
        private readonly NotesDbContext _context;

        public NotesController(NotesDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var notes = await _context.Notes
                .OrderByDescending(n => n.CreatedAt)
                .ToListAsync();
            return View(notes);
        }

        [HttpPost]
        public async Task<IActionResult> Create(string content, Priority priority)
        {
            if (!string.IsNullOrWhiteSpace(content))
            {
                _context.Notes.Add(new Note { Content = content, Priority = priority });
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, string content, Priority priority)
        {
            var note = await _context.Notes.FindAsync(id);
            if (note != null && !string.IsNullOrWhiteSpace(content))
            {
                note.Content = content;
                note.Priority = priority;
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var note = await _context.Notes.FindAsync(id);
            if (note != null)
            {
                _context.Notes.Remove(note);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
