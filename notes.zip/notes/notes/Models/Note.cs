﻿using System.ComponentModel.DataAnnotations;

namespace notes.Models
{
    public enum Priority
    {
        Low,
        Medium,
        High
    }

    public class Note
    {
        public int Id { get; set; }

        [Required]
        [StringLength(500)]
        public string Content { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Required]
        public Priority Priority { get; set; }
    }
}
